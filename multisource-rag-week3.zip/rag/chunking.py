from .config import CHUNK_WORDS, CHUNK_OVERLAP
def chunk_records(records):
    chunks=[]
    step=max(1,CHUNK_WORDS-CHUNK_OVERLAP)
    for record in records:
        words=record["text"].split()
        for start in range(0,len(words),step):
            part=words[start:start+CHUNK_WORDS]
            if not part: break
            chunks.append({"text":" ".join(part),"source":record["source"],"source_type":record["source_type"],"chunk_index":start//step})
            if start+CHUNK_WORDS>=len(words): break
    return chunks
