from sentence_transformers import CrossEncoder
from .config import RERANKER_MODEL,FINAL_K
class Reranker:
    def __init__(self): self.model=CrossEncoder(RERANKER_MODEL)
    def rank(self,question,candidates,k=None):
        if not candidates: return []
        scores=self.model.predict([[question,item["text"]] for item in candidates])
        ranked=sorted([{**item,"rerank_score":float(score)} for item,score in zip(candidates,scores)],key=lambda x:x["rerank_score"],reverse=True)
        return ranked[:(k or FINAL_K)]
