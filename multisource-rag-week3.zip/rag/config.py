import os
from dotenv import load_dotenv
load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
RERANKER_MODEL = os.getenv("RERANKER_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2")
CHUNK_WORDS = int(os.getenv("CHUNK_WORDS", "350"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "50"))
CANDIDATE_K = int(os.getenv("CANDIDATE_K", "10"))
FINAL_K = int(os.getenv("FINAL_K", "4"))
COLLECTION_NAME = "week3_multisource_rag"
