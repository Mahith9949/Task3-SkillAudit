import chromadb
from sentence_transformers import SentenceTransformer
from .config import EMBEDDING_MODEL,COLLECTION_NAME,CANDIDATE_K
class VectorStore:
    def __init__(self,path="chroma_db"):
        self.client=chromadb.PersistentClient(path=path)
        self.collection=self.client.get_or_create_collection(COLLECTION_NAME)
        self.embedder=SentenceTransformer(EMBEDDING_MODEL)
    def add_chunks(self,chunks):
        if not chunks: print("[WARN] No chunks to index."); return
        existing=set(self.collection.get(include=[])["ids"]); fresh=[]
        for chunk in chunks:
            doc_id=f'{chunk["source"]}::chunk-{chunk["chunk_index"]}'
            if doc_id not in existing: fresh.append((doc_id,chunk))
        if not fresh: print("[INFO] These chunks are already indexed."); return
        ids=[x[0] for x in fresh]; docs=[x[1]["text"] for x in fresh]
        metas=[{"source":x[1]["source"],"source_type":x[1]["source_type"],"chunk_index":x[1]["chunk_index"]} for x in fresh]
        vectors=self.embedder.encode(docs,normalize_embeddings=True).tolist()
        self.collection.add(ids=ids,documents=docs,metadatas=metas,embeddings=vectors)
        print(f"[INDEX] Added {len(ids)} chunks.")
    def search(self,query,k=None):
        if self.collection.count()==0: return []
        k=min(k or CANDIDATE_K,self.collection.count())
        vector=self.embedder.encode([query],normalize_embeddings=True).tolist()
        result=self.collection.query(query_embeddings=vector,n_results=k,include=["documents","metadatas","distances"])
        return [{"text":doc,**meta,"distance":float(dist)} for doc,meta,dist in zip(result["documents"][0],result["metadatas"][0],result["distances"][0])]
