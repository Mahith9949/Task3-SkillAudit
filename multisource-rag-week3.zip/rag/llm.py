from .config import API_KEY,GEMINI_MODEL
def answer(question,chunks):
    context="\n\n".join(f'[Source: {c["source"]} | type: {c["source_type"]}]\n{c["text"]}' for c in chunks)
    if not API_KEY:
        return ("DEMO MODE (no Gemini API key configured): Retrieved context is shown below. "
                "Add GEMINI_API_KEY to .env for a real model-generated answer.\n\n"+(context[:1800] if context else "No relevant context found."))
    import google.generativeai as genai
    genai.configure(api_key=API_KEY)
    model=genai.GenerativeModel(GEMINI_MODEL)
    prompt=("Answer using only the supplied context. If it does not support the answer, say so. "
            "Cite source filenames or URLs.\n\nCONTEXT:\n"+context+"\n\nQUESTION: "+question+"\nANSWER:")
    return model.generate_content(prompt).text
