from pathlib import Path
from urllib.parse import urlparse
import csv, requests
from bs4 import BeautifulSoup

def load_folder(folder="data/documents"):
    records=[]
    for path in sorted(Path(folder).rglob("*")):
        if not path.is_file(): continue
        suffix=path.suffix.lower()
        try:
            if suffix in {".md",".txt"}:
                records.append({"text":path.read_text(encoding="utf-8",errors="ignore"),"source":str(path),"source_type":suffix[1:]})
            elif suffix==".csv":
                with path.open(newline="",encoding="utf-8-sig") as f:
                    for i,row in enumerate(csv.DictReader(f),1):
                        text=" | ".join(f"{k}: {v}" for k,v in row.items() if v)
                        if text: records.append({"text":text,"source":f"{path}#row-{i}","source_type":"csv"})
            elif suffix==".pdf":
                from pypdf import PdfReader
                for i,page in enumerate(PdfReader(str(path)).pages,1):
                    text=page.extract_text() or ""
                    if text.strip(): records.append({"text":text,"source":f"{path}#page-{i}","source_type":"pdf"})
        except Exception as exc: print(f"[WARN] Could not load {path}: {exc}")
    return records

def load_webpage(url):
    response=requests.get(url,timeout=20,headers={"User-Agent":"Week3MultiSourceRAG/1.0"})
    response.raise_for_status()
    soup=BeautifulSoup(response.text,"html.parser")
    for tag in soup(["script","style","nav","footer","header","noscript"]): tag.decompose()
    text=" ".join(soup.get_text(" ").split())
    return {"text":text,"source":url,"source_type":"web","title":soup.title.get_text(" ",strip=True) if soup.title else urlparse(url).netloc}
