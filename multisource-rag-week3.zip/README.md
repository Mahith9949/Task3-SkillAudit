# Week 3 — Multi-Source RAG with Re-ranking
A Python RAG project that combines multiple source types in one persistent ChromaDB collection, retrieves a broad candidate pool, reranks with a cross-encoder, and splits multi-part questions into focused subqueries.

## Supported sources
- Markdown and TXT files
- CSV rows
- PDF pages via pypdf
- Webpage text via requests and BeautifulSoup (type `web https://...` in the CLI)

## Run locally
1. Install Python 3.10+.
2. `python -m venv .venv`
3. Windows: `.venv\\Scripts\\activate` | macOS/Linux: `source .venv/bin/activate`
4. `pip install -r requirements.txt`
5. Copy `.env.example` to `.env`. Add `GEMINI_API_KEY` for real Gemini answers. Without a key, the program clearly labels its fallback as DEMO MODE.
6. `python ingest.py`
7. `python main.py`

The first run downloads embedding and cross-encoder models, so it needs internet access. Add your own documents to `data/documents/`. Never commit `.env` or API keys.
