from rag.store import VectorStore
from rag.rerank import Reranker
from rag.llm import answer
from rag.loaders import load_webpage
from rag.chunking import chunk_records
from rag.config import CANDIDATE_K,FINAL_K
def main():
    store=VectorStore(); reranker=Reranker()
    print("="*66+"\nWEEK 3 | MULTI-SOURCE RAG WITH RE-RANKING\nType 'web <URL>' to add a page, or 'exit' to quit.\n"+"="*66)
    while True:
        question=input("\nQuestion> ").strip()
        if question.lower() in {"exit","quit"}: break
        if not question: continue
        if question.lower().startswith("web "):
            url=question[4:].strip()
            try:
                store.add_chunks(chunk_records([load_webpage(url)])); print(f"[WEB] Added webpage source: {url}")
            except Exception as exc: print(f"[ERROR] Web ingestion failed: {exc}")
            continue
        subqueries=[question]
        if " and " in question.lower():
            subqueries=[p.strip() for p in question.split(" and ",1) if p.strip()]
            print(f"[REWRITE] Split into {len(subqueries)} focused sub-queries:")
            for i,q in enumerate(subqueries,1): print(f"  {i}. {q}")
        pool=[]; seen=set()
        for q in subqueries:
            for item in store.search(q,k=CANDIDATE_K):
                key=(item["source"],item["chunk_index"])
                if key not in seen: seen.add(key); pool.append(item)
        print(f"[RETRIEVE] Candidate chunks: {len(pool)} (top-{CANDIDATE_K} per sub-query)")
        ranked=reranker.rank(question,pool,k=FINAL_K)
        print(f"[RERANK] Reduced candidate pool to top {len(ranked)} chunks")
        for i,item in enumerate(ranked,1):
            print(f'\n[{i}] {item["source_type"].upper()} | {item["source"]} | score={item["rerank_score"]:.3f}')
            print(item["text"][:420])
        print("\n"+"-"*66+"\nANSWER\n"+answer(question,ranked)+"\n"+"-"*66)
if __name__=="__main__": main()
