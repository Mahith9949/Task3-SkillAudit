from rag.loaders import load_folder
from rag.chunking import chunk_records
from rag.store import VectorStore
def main():
    print("="*66+"\nWEEK 3 | MULTI-SOURCE RAG WITH RE-RANKING\nDOCUMENT INGESTION\n"+"="*66)
    records=load_folder()
    print(f"[LOAD] Source records loaded: {len(records)}")
    print("[LOAD] Source types: "+(", ".join(sorted({r["source_type"] for r in records})) or "none"))
    chunks=chunk_records(records)
    print(f"[CHUNK] Created {len(chunks)} overlapping chunks")
    VectorStore().add_chunks(chunks)
    print("[DONE] Ingestion complete. Run: python main.py")
if __name__=="__main__": main()
